package com.cmyk.gitbuild;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

/** PriceRec-style green circular check: #227733 with #FFFFFF check. */
public final class GreenCheckView extends View {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    public GreenCheckView(Context c){super(c);} public GreenCheckView(Context c, AttributeSet a){super(c,a);}
    @Override protected void onMeasure(int w,int h){int s=resolveSize(dp(20),w);setMeasuredDimension(s,s);}
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        float s=Math.min(getWidth(),getHeight());
        paint.setStyle(Paint.Style.FILL); paint.setColor(Color.rgb(34,119,51));
        c.drawCircle(getWidth()/2f,getHeight()/2f,s/2f,paint);
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dpF(2f)); paint.setStrokeCap(Paint.Cap.SQUARE); paint.setStrokeJoin(Paint.Join.MITER); paint.setColor(Color.WHITE);
        android.graphics.Path p=new android.graphics.Path();
        p.moveTo(s*0.27f,s*0.52f); p.lineTo(s*0.44f,s*0.69f); p.lineTo(s*0.75f,s*0.34f);
        c.drawPath(p,paint);
    }
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);} private float dpF(float v){return v*getResources().getDisplayMetrics().density;}
}
