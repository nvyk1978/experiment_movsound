package com.cmyk.gitbuild;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

public final class GitHubOAuth {
    public static final class TokenResult {
        public final String accessToken;
        public final String refreshToken;
        public final long accessExpiresAt;
        public final long refreshExpiresAt;
        TokenResult(String accessToken, String refreshToken, long accessExpiresAt, long refreshExpiresAt) {
            this.accessToken = accessToken;
            this.refreshToken = refreshToken;
            this.accessExpiresAt = accessExpiresAt;
            this.refreshExpiresAt = refreshExpiresAt;
        }
    }

    private static TokenResult tokenRequest(Map<String,String> form) throws Exception {
        DiagnosticLog.log("OAUTH_HTTP token request grant="+(form.containsKey("grant_type")?form.get("grant_type"):"authorization_code")+" redirectPresent="+form.containsKey("redirect_uri")+" verifierPresent="+form.containsKey("code_verifier"));
        HttpURLConnection c = (HttpURLConnection) new URL("https://github.com/login/oauth/access_token").openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(20000);
        c.setReadTimeout(30000);
        c.setDoOutput(true);
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
        c.setRequestProperty("User-Agent", "GitBuild-Android");
        StringBuilder body = new StringBuilder();
        for (Map.Entry<String,String> e : form.entrySet()) {
            if (body.length() > 0) body.append('&');
            body.append(enc(e.getKey())).append('=').append(enc(e.getValue()));
        }
        byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
        c.setFixedLengthStreamingMode(bytes.length);
        try (OutputStream out = c.getOutputStream()) { out.write(bytes); }
        int code = c.getResponseCode();
        DiagnosticLog.log("OAUTH_HTTP token response status="+code);
        String text = read(code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream());
        if (code < 200 || code >= 300) { DiagnosticLog.log("OAUTH_HTTP token error body="+text); throw new Exception("OAuth HTTP " + code + ": " + text); }
        JSONObject j = new JSONObject(text);
        if (j.has("error")) { DiagnosticLog.log("OAUTH_HTTP token json error="+j.optString("error")+" description="+j.optString("error_description")); throw new Exception(j.optString("error_description", j.optString("error"))); }
        String access = j.optString("access_token", "");
        if (access.isEmpty()) throw new Exception("GitHubからアクセストークンを取得できませんでした");
        long now = System.currentTimeMillis();
        long accessExp = j.has("expires_in") ? now + j.optLong("expires_in", 0) * 1000L : 0;
        String refresh = j.optString("refresh_token", "");
        long refreshExp = j.has("refresh_token_expires_in") ? now + j.optLong("refresh_token_expires_in", 0) * 1000L : 0;
        DiagnosticLog.log("OAUTH_HTTP token parsed accessPresent="+(!access.isEmpty())+" refreshPresent="+(!refresh.isEmpty())+" expiresIn="+j.optLong("expires_in",0));
        return new TokenResult(access, refresh.isEmpty() ? null : refresh, accessExp, refreshExp);
    }

    public static TokenResult exchange(String clientId, String clientSecret, String code,
                                       String redirectUri, String codeVerifier) throws Exception {
        Map<String,String> f = new LinkedHashMap<>();
        f.put("client_id", clientId);
        f.put("client_secret", clientSecret);
        f.put("code", code);
        f.put("redirect_uri", redirectUri);
        f.put("code_verifier", codeVerifier);
        return tokenRequest(f);
    }

    public static TokenResult refresh(String clientId, String clientSecret, String refreshToken) throws Exception {
        Map<String,String> f = new LinkedHashMap<>();
        f.put("client_id", clientId);
        f.put("client_secret", clientSecret);
        f.put("grant_type", "refresh_token");
        f.put("refresh_token", refreshToken);
        return tokenRequest(f);
    }

    private static String enc(String s) throws Exception { return URLEncoder.encode(s, "UTF-8").replace("+", "%20"); }
    private static String read(InputStream in) throws Exception {
        if (in == null) return "";
        try (InputStream input = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192]; int n;
            while ((n = input.read(buf)) >= 0) out.write(buf, 0, n);
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }
}
