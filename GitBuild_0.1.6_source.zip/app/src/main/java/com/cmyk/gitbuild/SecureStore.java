package com.cmyk.gitbuild;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public final class SecureStore {
    private static final String KEY_ALIAS = "GitBuildSecureKeyV2";
    private static final String PREF = "gitbuild_secure_v2";
    private final Context context;

    public SecureStore(Context context) { this.context = context.getApplicationContext(); }

    private SharedPreferences prefs() { return context.getSharedPreferences(PREF, Context.MODE_PRIVATE); }

    private SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (!ks.containsAlias(KEY_ALIAS)) {
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            kg.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .build());
            kg.generateKey();
        }
        return (SecretKey) ks.getKey(KEY_ALIAS, null);
    }

    public void putSecret(String name, String value) throws Exception {
        if (value == null || value.isEmpty()) { removeSecret(name); return; }
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key());
        byte[] encrypted = c.doFinal(value.getBytes(StandardCharsets.UTF_8));
        prefs().edit()
                .putString(name + "_ct", Base64.encodeToString(encrypted, Base64.NO_WRAP))
                .putString(name + "_iv", Base64.encodeToString(c.getIV(), Base64.NO_WRAP))
                .apply();
    }

    public String getSecret(String name) {
        try {
            String enc = prefs().getString(name + "_ct", null);
            String iv = prefs().getString(name + "_iv", null);
            if (enc == null || iv == null) return null;
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP)));
            return new String(c.doFinal(Base64.decode(enc, Base64.NO_WRAP)), StandardCharsets.UTF_8);
        } catch (Exception e) { DiagnosticLog.error("SECURE getSecret name="+name, e); return null; }
    }

    public void removeSecret(String name) {
        prefs().edit().remove(name + "_ct").remove(name + "_iv").apply();
    }

    public void putString(String name, String value) { prefs().edit().putString(name, value).apply(); }
    public void remove(String name) { prefs().edit().remove(name).apply(); }
    public String getString(String name) { return prefs().getString(name, null); }
    public void putLong(String name, long value) { prefs().edit().putLong(name, value).apply(); }
    public long getLong(String name, long def) { return prefs().getLong(name, def); }

    public void clearTokens() {
        removeSecret("access_token");
        removeSecret("refresh_token");
        prefs().edit().remove("access_expires_at").remove("refresh_expires_at").remove("login").apply();
    }

    public void clearOAuthPending() {
        removeSecret("oauth_verifier");
        prefs().edit().remove("oauth_state").remove("oauth_redirect").remove("oauth_started_at").apply();
    }
}
