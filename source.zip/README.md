# Audio Capture Probe v0.3.0

Private experimental Android screen recorder for Android 10+ / target SDK 36.

## v0.3.0
- Floating REC button immediately opens Android's MediaProjection permission UI; no extra app confirmation dialog.
- After permission: overlay countdown `3 -> 2 -> 1 -> START`.
- No VirtualDisplay/capture surface is created until the countdown overlay is removed, so the REC float/countdown are intentionally excluded from the recording.
- Persistent recording notification uses an N-style dark launcher with a dedicated Stop button.
- Settings screen also has a Stop button.
- Notification Stop and settings Stop both call the same CaptureService stop action and share one persistent recording state.
- Fixed the preparation-stop dead path: stopping before the controller starts now cancels countdown/projection and shuts the service down immediately.
- Added 5 s worker-break watchdog and 10 s absolute cleanup fallback so a stuck codec/audio worker cannot leave an unstoppable recording service.
- Stop releases audio, VirtualDisplay, MediaProjection, codecs, muxer/output, foreground notification, and restores the original media volume.
- Keeps native rendered display size/aspect ratio, H.264 60 fps target, automatic bitrate, AAC internal playback audio.
- No crop, aspect correction, or upscale.
- Output: Movies/AudioCaptureProbe/capture_YYYYMMDD_HHMMSS.mp4

## Overwrite install
- applicationId remains `jp.groovy.audiocaptureprobe`.
- versionCode increased to 3, versionName to 0.3.0.
- The same bundled fixed signing key is retained, so this and future builds can overwrite-install previous fixed-key builds.

## Limits
- Audio from apps that disallow AudioPlaybackCapture cannot be captured by a normal third-party app.
- FLAG_SECURE / protected video may be blank or otherwise blocked by Android.
- This build deliberately fails rather than silently scaling the screen if the device H.264 encoder cannot encode the native display size at 60 fps.
