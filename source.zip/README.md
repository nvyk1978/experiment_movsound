# Audio Capture Probe v0.2.0

Private experimental Android screen recorder for Android 10+ / target SDK 36.

## v0.2.0
- Floating REC button can be placed over the target app.
- Tapping REC opens the system MediaProjection permission screen.
- The float disappears before encoding begins so it is not intentionally burned into the recording.
- Records the currently rendered default display without aspect-ratio correction, automatic crop, or upscale.
- H.264, native display pixel size, 60 fps target.
- Video bitrate is chosen automatically from pixel count: width x height x 60 x 0.10 bits/pixel/frame, then clamped to encoder limits and 6-80 Mbps.
- Internal playback audio uses AudioPlaybackCapture -> AAC-LC 48 kHz stereo 192 kbps.
- Device media volume is set to 0 when recording starts and restored to its previous level when recording ends.
- Recording stops from the foreground notification.
- Output: Movies/AudioCaptureProbe/capture_YYYYMMDD_HHMMSS.mp4
- Fixed debug signing key is bundled for overwrite-install testing across GitHub Actions builds.

## Limits
- Audio from apps that disallow AudioPlaybackCapture cannot be captured by a normal third-party app.
- FLAG_SECURE / protected video may be blank or otherwise blocked by Android.
- This build deliberately fails rather than silently scale the screen if the device H.264 encoder cannot encode the native display size at 60 fps.
