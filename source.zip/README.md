# Audio Capture Probe v0.1.0
Experimental Android app for testing AudioPlaybackCapture while device media volume is zero.

## Test
1. Start media in another app and pause it.
2. Open Audio Capture Probe and tap capture.
3. Approve system screen-capture permission.
4. Return to media app and play for 10 seconds.
5. WAV is saved under Music/AudioCaptureProbe.
6. Repeat once with normal volume and once with media volume = 0.

The completion notification includes avg sample amplitude and captured PCM byte count. If bytes exist but avg is ~0, the capture stream is silent.
