package jp.groovy.audiocaptureprobe;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public final class CaptureState {
    public static final String ACTION_CHANGED = "jp.groovy.audiocaptureprobe.CAPTURE_STATE_CHANGED";
    public static final String EXTRA_STATE = "state";
    public static final String EXTRA_DETAIL = "detail";

    public static final String IDLE = "idle";
    public static final String COUNTDOWN = "countdown";
    public static final String RECORDING = "recording";
    public static final String STOPPING = "stopping";

    private static final String PREFS = "capture_state";
    private static final String KEY_STATE = "state";
    private static final String KEY_DETAIL = "detail";

    private CaptureState() {}

    public static void set(Context context, String state, String detail) {
        Context app = context.getApplicationContext();
        SharedPreferences p = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        p.edit().putString(KEY_STATE, state).putString(KEY_DETAIL, detail == null ? "" : detail).apply();
        Intent i = new Intent(ACTION_CHANGED);
        i.setPackage(app.getPackageName());
        i.putExtra(EXTRA_STATE, state);
        i.putExtra(EXTRA_DETAIL, detail == null ? "" : detail);
        app.sendBroadcast(i);
    }

    public static String getState(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_STATE, IDLE);
    }

    public static String getDetail(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_DETAIL, "");
    }

    public static boolean isActive(Context context) {
        String s = getState(context);
        return COUNTDOWN.equals(s) || RECORDING.equals(s) || STOPPING.equals(s);
    }
}
