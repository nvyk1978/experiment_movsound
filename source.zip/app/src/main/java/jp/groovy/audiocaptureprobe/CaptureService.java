package jp.groovy.audiocaptureprobe;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.*;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Range;
import android.view.Display;
import android.view.Gravity;
import android.view.Surface;
import android.view.WindowManager;
import android.widget.RemoteViews;
import android.widget.TextView;

import java.io.FileDescriptor;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class CaptureService extends Service {
    private static volatile boolean serviceAlive;

    public static boolean isServiceAlive() { return serviceAlive; }

    public static final String ACTION_START = "jp.groovy.audiocaptureprobe.START_CAPTURE";
    public static final String ACTION_STOP = "jp.groovy.audiocaptureprobe.STOP_CAPTURE";
    public static final String EXTRA_RESULT_CODE = "resultCode";
    public static final String EXTRA_RESULT_DATA = "resultData";

    private static final String CHANNEL = "screen_recording";
    private static final int NOTIFICATION_ID = 50;
    private static final int VIDEO_FPS = 60;
    private static final int AUDIO_RATE = 48000;
    private static final int AUDIO_CHANNELS = 2;
    private static final int AUDIO_BITRATE = 192000;

    private final AtomicBoolean stopRequested = new AtomicBoolean(false);
    private final AtomicBoolean cleanedUp = new AtomicBoolean(false);
    private final AtomicBoolean outputFinalized = new AtomicBoolean(false);
    private final AtomicBoolean watchdogScheduled = new AtomicBoolean(false);

    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private MediaProjection projection;
    private MediaProjection.Callback projectionCallback;
    private VirtualDisplay virtualDisplay;
    private MediaCodec videoCodec;
    private MediaCodec audioCodec;
    private Surface videoInputSurface;
    private AudioRecord audioRecord;
    private MediaMuxer muxer;
    private ParcelFileDescriptor outputPfd;
    private Uri outputUri;
    private MuxerGate muxerGate;
    private Thread controllerThread;
    private Thread videoDrainThread;
    private Thread audioThread;

    private volatile boolean captureStarted;
    private volatile int videoBitrate;
    private volatile int captureWidth;
    private volatile int captureHeight;

    private AudioManager audioManager;
    private int originalMusicVolume = -1;
    private boolean mediaVolumeChanged;

    private WindowManager countdownWindowManager;
    private TextView countdownView;
    private Runnable countdownRunnable;

    @Override public void onCreate() {
        super.onCreate();
        serviceAlive = true;
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel ch = new NotificationChannel(
                CHANNEL, "Screen recording", NotificationManager.IMPORTANCE_LOW);
        ch.setDescription("Audio Capture Probe recording state");
        ch.setSound(null, null);
        nm.createNotificationChannel(ch);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            requestStop("停止処理中…");
            return START_NOT_STICKY;
        }

        if (captureStarted || controllerThread != null || projection != null) {
            return START_NOT_STICKY;
        }
        if (intent == null || !ACTION_START.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }

        int resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED);
        Intent resultData;
        if (Build.VERSION.SDK_INT >= 33) {
            resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent.class);
        } else {
            //noinspection deprecation
            resultData = intent.getParcelableExtra(EXTRA_RESULT_DATA);
        }
        if (resultCode != Activity.RESULT_OK || resultData == null) {
            CaptureState.set(this, CaptureState.IDLE, "録画許可がありません");
            stopSelf();
            return START_NOT_STICKY;
        }

        startForeground(NOTIFICATION_ID, buildRecordingNotification("録画開始準備中…"),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);

        try {
            MediaProjectionManager mpm =
                    (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(resultCode, resultData);
            if (projection == null) throw new IllegalStateException("MediaProjection unavailable");

            projectionCallback = new MediaProjection.Callback() {
                @Override public void onStop() {
                    requestStop("システムにより停止中…");
                }
            };
            projection.registerCallback(projectionCallback, mainHandler);
            beginCountdown();
        } catch (Throwable e) {
            notifyError(e);
            CaptureState.set(this, CaptureState.IDLE, "録画開始に失敗しました");
            cleanup();
        }
        return START_NOT_STICKY;
    }

    private void beginCountdown() {
        if (stopRequested.get()) {
            cleanup();
            return;
        }
        CaptureState.set(this, CaptureState.COUNTDOWN, "録画開始まで 3");
        updateRecordingNotification("録画開始まで 3");

        if (!Settings.canDrawOverlays(this)) {
            // Overlay permission should already exist because recording is launched from the float.
            // If it was revoked between tap and permission grant, fail safely rather than recording
            // without the requested countdown.
            notifyError(new IllegalStateException("フロート表示権限がありません"));
            cleanup();
            return;
        }

        showCountdownOverlay("3", false);
        countdownRunnable = new Runnable() {
            int step = 0;
            @Override public void run() {
                if (stopRequested.get() || cleanedUp.get()) return;
                step++;
                if (step == 1) {
                    updateCountdown("2", false, "録画開始まで 2");
                    mainHandler.postDelayed(this, 1000);
                } else if (step == 2) {
                    updateCountdown("1", false, "録画開始まで 1");
                    mainHandler.postDelayed(this, 1000);
                } else if (step == 3) {
                    updateCountdown("START", true, "録画開始");
                    mainHandler.postDelayed(this, 420);
                } else {
                    removeCountdownOverlay();
                    // Give SurfaceFlinger a short moment to remove our overlay before the
                    // VirtualDisplay is created. No capture surface exists before this point.
                    mainHandler.postDelayed(CaptureService.this::launchController, 140);
                }
            }
        };
        mainHandler.postDelayed(countdownRunnable, 1000);
    }

    private void showCountdownOverlay(String text, boolean wide) {
        mainHandler.post(() -> {
            if (stopRequested.get() || cleanedUp.get()) return;
            try {
                countdownWindowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
                TextView v = new TextView(this);
                v.setText(text);
                v.setTextColor(Color.WHITE);
                v.setTextSize(wide ? 22f : 36f);
                v.setGravity(Gravity.CENTER);
                v.setBackgroundResource(R.drawable.countdown_bg);
                v.setElevation(dp(10));

                WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                        dp(wide ? 140 : 96), dp(wide ? 68 : 96),
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                        PixelFormat.TRANSLUCENT);
                p.gravity = Gravity.CENTER;
                countdownView = v;
                countdownWindowManager.addView(v, p);
            } catch (Exception e) {
                notifyError(e);
                requestStop("カウントダウン表示失敗");
            }
        });
    }

    private void updateCountdown(String text, boolean wide, String detail) {
        CaptureState.set(this, CaptureState.COUNTDOWN, detail);
        updateRecordingNotification(detail);
        mainHandler.post(() -> {
            if (countdownView == null || countdownWindowManager == null) return;
            try {
                countdownView.setText(text);
                countdownView.setTextSize(wide ? 22f : 36f);
                WindowManager.LayoutParams p = (WindowManager.LayoutParams)countdownView.getLayoutParams();
                p.width = dp(wide ? 140 : 96);
                p.height = dp(wide ? 68 : 96);
                countdownWindowManager.updateViewLayout(countdownView, p);
            } catch (Exception ignored) {}
        });
    }

    private void cancelCountdown() {
        if (countdownRunnable != null) {
            mainHandler.removeCallbacks(countdownRunnable);
            countdownRunnable = null;
        }
    }

    private void removeCountdownOverlay() {
        mainHandler.post(() -> {
            if (countdownView != null && countdownWindowManager != null) {
                try { countdownWindowManager.removeView(countdownView); } catch (Exception ignored) {}
            }
            countdownView = null;
            countdownWindowManager = null;
        });
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void launchController() {
        if (cleanedUp.get()) return;
        if (stopRequested.get()) {
            cleanup();
            return;
        }
        if (controllerThread != null) return;
        controllerThread = new Thread(this::runCapture, "capture-controller");
        controllerThread.start();
    }

    private void runCapture() {
        boolean success = false;
        try {
            throwIfStopRequested();
            setupOutput();
            throwIfStopRequested();
            readDisplaySize();
            throwIfStopRequested();
            muteDeviceMedia();
            throwIfStopRequested();
            setupVideoEncoder();
            throwIfStopRequested();
            setupAudioEncoderAndRecord();
            throwIfStopRequested();

            muxerGate = new MuxerGate(muxer);
            muxerGate.setOnStarted(() -> {
                try {
                    Bundle b = new Bundle();
                    b.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0);
                    videoCodec.setParameters(b);
                } catch (Exception ignored) {}
            });

            videoCodec.start();
            audioCodec.start();
            throwIfStopRequested();

            videoDrainThread = new Thread(this::drainVideo, "video-drain");
            audioThread = new Thread(this::runAudio, "audio-capture");
            videoDrainThread.start();
            audioThread.start();
            throwIfStopRequested();

            int densityDpi = getResources().getDisplayMetrics().densityDpi;
            virtualDisplay = projection.createVirtualDisplay(
                    "AudioCaptureProbe",
                    captureWidth,
                    captureHeight,
                    densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    videoInputSurface,
                    null,
                    null);
            if (virtualDisplay == null) throw new IllegalStateException("VirtualDisplay creation failed");

            captureStarted = true;
            String detail = String.format(Locale.US,
                    "録画中 %dx%d / 60fps / %.1fMbps",
                    captureWidth, captureHeight, videoBitrate / 1_000_000.0);
            CaptureState.set(this, CaptureState.RECORDING, detail);
            updateRecordingNotification(detail);

            while (!stopRequested.get()) {
                try { Thread.sleep(100); }
                catch (InterruptedException ignored) { /* re-check stopRequested */ }
            }

            stopInputStreams();
            joinQuietly(audioThread, 3500);
            joinQuietly(videoDrainThread, 3500);

            success = true;
            finishOutput(true);
            notifyDone();
        } catch (Throwable e) {
            finishOutput(false);
            if (!stopRequested.get()) notifyError(e);
        } finally {
            if (!success && !outputFinalized.get()) finishOutput(false);
            cleanup();
        }
    }

    private void throwIfStopRequested() throws InterruptedException {
        if (stopRequested.get()) throw new InterruptedException("capture stop requested");
    }

    private void requestStop(String detail) {
        if (cleanedUp.get()) return;
        stopRequested.set(true);
        CaptureState.set(this, CaptureState.STOPPING, detail);
        try { updateRecordingNotification(detail); } catch (Exception ignored) {}

        cancelCountdown();
        removeCountdownOverlay();
        stopInputStreams();

        Thread c = controllerThread;
        if (c != null) c.interrupt();
        Thread a = audioThread;
        if (a != null) a.interrupt();
        Thread v = videoDrainThread;
        if (v != null) v.interrupt();

        if (c == null || !c.isAlive()) {
            // This closes the old bug where STOP during the preparation delay left the
            // foreground service alive forever because the controller never started.
            finishOutput(false);
            cleanup();
            return;
        }

        scheduleStopWatchdog();
    }

    private void stopInputStreams() {
        try { if (audioRecord != null) audioRecord.stop(); } catch (Exception ignored) {}
        try { if (videoCodec != null) videoCodec.signalEndOfInputStream(); } catch (Exception ignored) {}
        try {
            if (virtualDisplay != null) {
                virtualDisplay.release();
                virtualDisplay = null;
            }
        } catch (Exception ignored) {}
    }

    private void scheduleStopWatchdog() {
        if (!watchdogScheduled.compareAndSet(false, true)) return;

        mainHandler.postDelayed(() -> {
            if (cleanedUp.get()) return;
            // First fallback: forcibly break MediaCodec/AudioRecord waits so the controller
            // can finish its normal cleanup path.
            forceReleaseCaptureWorkers();
            Thread c = controllerThread;
            if (c != null) c.interrupt();
        }, 5000);

        mainHandler.postDelayed(() -> {
            if (cleanedUp.get()) return;
            // Absolute fallback: never leave an unstoppable recording service behind.
            finishOutput(false);
            cleanup();
        }, 10000);
    }

    private void forceReleaseCaptureWorkers() {
        try { if (audioRecord != null) audioRecord.stop(); } catch (Exception ignored) {}
        try { if (audioRecord != null) audioRecord.release(); } catch (Exception ignored) {}
        audioRecord = null;
        try { if (virtualDisplay != null) virtualDisplay.release(); } catch (Exception ignored) {}
        virtualDisplay = null;
        try { if (videoCodec != null) videoCodec.stop(); } catch (Exception ignored) {}
        try { if (audioCodec != null) audioCodec.stop(); } catch (Exception ignored) {}
    }

    private void readDisplaySize() {
        DisplayManager dm = (DisplayManager)getSystemService(DISPLAY_SERVICE);
        Display display = dm.getDisplay(Display.DEFAULT_DISPLAY);
        if (display == null) throw new IllegalStateException("Default display not found");
        DisplayMetrics metrics = new DisplayMetrics();
        //noinspection deprecation
        display.getRealMetrics(metrics);
        captureWidth = metrics.widthPixels & ~1;
        captureHeight = metrics.heightPixels & ~1;
        if (captureWidth < 2 || captureHeight < 2) {
            throw new IllegalStateException("Invalid display size");
        }
    }

    private void muteDeviceMedia() {
        try {
            audioManager = (AudioManager)getSystemService(AUDIO_SERVICE);
            if (audioManager == null) return;
            originalMusicVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            if (originalMusicVolume != 0) {
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0);
                mediaVolumeChanged = true;
            }
        } catch (Exception ignored) {}
    }

    private void restoreDeviceMedia() {
        if (!mediaVolumeChanged || audioManager == null || originalMusicVolume < 0) return;
        try {
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, originalMusicVolume, 0);
        } catch (Exception ignored) {}
        mediaVolumeChanged = false;
    }

    private void setupOutput() throws Exception {
        String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        ContentValues v = new ContentValues();
        v.put(MediaStore.Video.Media.DISPLAY_NAME, "capture_" + ts + ".mp4");
        v.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        v.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AudioCaptureProbe");
        v.put(MediaStore.Video.Media.IS_PENDING, 1);
        outputUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v);
        if (outputUri == null) throw new IllegalStateException("MediaStore insert failed");
        outputPfd = getContentResolver().openFileDescriptor(outputUri, "rw");
        if (outputPfd == null) throw new IllegalStateException("Output FileDescriptor unavailable");
        FileDescriptor fd = outputPfd.getFileDescriptor();
        muxer = new MediaMuxer(fd, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
    }

    private void setupVideoEncoder() throws Exception {
        videoCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
        MediaCodecInfo.CodecCapabilities caps = videoCodec.getCodecInfo()
                .getCapabilitiesForType(MediaFormat.MIMETYPE_VIDEO_AVC);
        MediaCodecInfo.VideoCapabilities vc = caps.getVideoCapabilities();

        int desired = (int)Math.round((double)captureWidth * captureHeight * VIDEO_FPS * 0.10d);
        desired = Math.max(6_000_000, Math.min(80_000_000, desired));
        Range<Integer> range = vc.getBitrateRange();
        videoBitrate = Math.max(range.getLower(), Math.min(range.getUpper(), desired));

        if (!vc.areSizeAndRateSupported(captureWidth, captureHeight, VIDEO_FPS)) {
            throw new IllegalStateException("H.264 encoder does not support native display size at 60fps: "
                    + captureWidth + "x" + captureHeight);
        }

        MediaFormat f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC,
                captureWidth, captureHeight);
        f.setInteger(MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        f.setInteger(MediaFormat.KEY_BIT_RATE, videoBitrate);
        f.setInteger(MediaFormat.KEY_FRAME_RATE, VIDEO_FPS);
        f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
        MediaCodecInfo.EncoderCapabilities ec = caps.getEncoderCapabilities();
        if (ec != null && ec.isBitrateModeSupported(
                MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)) {
            f.setInteger(MediaFormat.KEY_BITRATE_MODE,
                    MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR);
        }
        videoCodec.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        videoInputSurface = videoCodec.createInputSurface();
    }

    private void setupAudioEncoderAndRecord() {
        try {
            AudioPlaybackCaptureConfiguration cfg =
                    new AudioPlaybackCaptureConfiguration.Builder(projection)
                            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                            .addMatchingUsage(AudioAttributes.USAGE_GAME)
                            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                            .build();

            AudioFormat audioFormat = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(AUDIO_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                    .build();

            int min = AudioRecord.getMinBufferSize(AUDIO_RATE,
                    AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT);
            int buffer = Math.max(min * 2, 48_000);
            audioRecord = new AudioRecord.Builder()
                    .setAudioFormat(audioFormat)
                    .setBufferSizeInBytes(buffer)
                    .setAudioPlaybackCaptureConfig(cfg)
                    .build();
            if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED) {
                throw new IllegalStateException("AudioRecord init failed");
            }

            MediaFormat aac = MediaFormat.createAudioFormat(
                    MediaFormat.MIMETYPE_AUDIO_AAC, AUDIO_RATE, AUDIO_CHANNELS);
            aac.setInteger(MediaFormat.KEY_AAC_PROFILE,
                    MediaCodecInfo.CodecProfileLevel.AACObjectLC);
            aac.setInteger(MediaFormat.KEY_BIT_RATE, AUDIO_BITRATE);
            aac.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, buffer);
            audioCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
            audioCodec.configure(aac, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        } catch (Exception e) {
            throw new IllegalStateException("Internal audio setup failed: " + e, e);
        }
    }

    private void drainVideo() {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        boolean eos = false;
        while (!eos && !cleanedUp.get()) {
            int out;
            try {
                out = videoCodec.dequeueOutputBuffer(info, 20_000);
            } catch (Exception e) {
                break;
            }
            if (out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                try { muxerGate.onVideoFormat(videoCodec.getOutputFormat()); }
                catch (Exception e) { stopRequested.set(true); break; }
            } else if (out >= 0) {
                try {
                    java.nio.ByteBuffer buf = videoCodec.getOutputBuffer(out);
                    if (buf != null && info.size > 0 &&
                            (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        muxerGate.writeVideo(buf, info);
                    }
                    eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                    videoCodec.releaseOutputBuffer(out, false);
                } catch (Exception e) {
                    break;
                }
            }
        }
    }

    private void runAudio() {
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        byte[] pcm = new byte[24_000];
        long submittedFrames = 0;
        boolean inputEos = false;
        boolean outputEos = false;

        try { audioRecord.startRecording(); }
        catch (Exception e) { stopRequested.set(true); return; }

        while (!outputEos && !cleanedUp.get()) {
            try {
                if (!inputEos) {
                    int in = audioCodec.dequeueInputBuffer(10_000);
                    if (in >= 0) {
                        java.nio.ByteBuffer ib = audioCodec.getInputBuffer(in);
                        if (ib != null) {
                            ib.clear();
                            if (!stopRequested.get()) {
                                int max = Math.min(pcm.length, ib.remaining());
                                int n = audioRecord.read(pcm, 0, max);
                                if (n > 0) {
                                    ib.put(pcm, 0, n);
                                    long ptsUs = submittedFrames * 1_000_000L / AUDIO_RATE;
                                    int frames = n / (2 * AUDIO_CHANNELS);
                                    submittedFrames += frames;
                                    audioCodec.queueInputBuffer(in, 0, n, ptsUs, 0);
                                } else {
                                    audioCodec.queueInputBuffer(in, 0, 0,
                                            submittedFrames * 1_000_000L / AUDIO_RATE, 0);
                                }
                            } else {
                                audioCodec.queueInputBuffer(in, 0, 0,
                                        submittedFrames * 1_000_000L / AUDIO_RATE,
                                        MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                                inputEos = true;
                            }
                        }
                    }
                }

                int out = audioCodec.dequeueOutputBuffer(info, 10_000);
                if (out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    muxerGate.onAudioFormat(audioCodec.getOutputFormat());
                } else if (out >= 0) {
                    java.nio.ByteBuffer ob = audioCodec.getOutputBuffer(out);
                    if (ob != null && info.size > 0 &&
                            (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        muxerGate.writeAudio(ob, info);
                    }
                    outputEos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                    audioCodec.releaseOutputBuffer(out, false);
                }
            } catch (Exception e) {
                break;
            }
        }
    }

    private PendingIntent stopPendingIntent() {
        Intent stop = new Intent(this, CaptureService.class).setAction(ACTION_STOP);
        return PendingIntent.getService(this, 1, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private Notification buildRecordingNotification(String text) {
        PendingIntent stopPi = stopPendingIntent();
        Intent open = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 2, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        RemoteViews compact = new RemoteViews(getPackageName(), R.layout.notification_capture);
        compact.setTextViewText(R.id.notifStatus, text);
        compact.setOnClickPendingIntent(R.id.notifStop, stopPi);

        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.presence_video_busy)
                .setContentTitle("Audio Capture Probe")
                .setContentText(text)
                .setContentIntent(openPi)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCustomContentView(compact)
                .setCustomBigContentView(compact)
                .setStyle(new Notification.DecoratedCustomViewStyle())
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_media_pause, "停止", stopPi).build())
                .build();
    }

    private void updateRecordingNotification(String text) {
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE))
                .notify(NOTIFICATION_ID, buildRecordingNotification(text));
    }

    private void finishOutput(boolean success) {
        if (!outputFinalized.compareAndSet(false, true)) return;
        if (muxerGate != null) {
            try { muxerGate.stop(); } catch (Exception ignored) {}
        } else if (muxer != null) {
            try { muxer.release(); } catch (Exception ignored) {}
        }
        muxer = null;

        if (outputPfd != null) {
            try { outputPfd.close(); } catch (Exception ignored) {}
            outputPfd = null;
        }
        if (outputUri != null) {
            try {
                if (success) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.Video.Media.IS_PENDING, 0);
                    getContentResolver().update(outputUri, v, null, null);
                } else {
                    getContentResolver().delete(outputUri, null, null);
                    outputUri = null;
                }
            } catch (Exception ignored) {}
        }
    }

    private void notifyDone() {
        String text = String.format(Locale.US, "保存完了 %dx%d / %.1fMbps",
                captureWidth, captureHeight, videoBitrate / 1_000_000.0);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("録画完了")
                .setContentText(text)
                .setAutoCancel(true)
                .build();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(51, n);
    }

    private void notifyError(Throwable e) {
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_notify_error)
                .setContentTitle("録画失敗")
                .setContentText(shortError(e))
                .setStyle(new Notification.BigTextStyle().bigText(e.toString()))
                .setAutoCancel(true)
                .build();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(52, n);
    }

    private String shortError(Throwable e) {
        String s = e.getMessage();
        if (s == null || s.isEmpty()) s = e.getClass().getSimpleName();
        return s.length() > 120 ? s.substring(0, 120) : s;
    }

    private void cleanup() {
        cleanup(true);
    }

    private void cleanup(boolean stopService) {
        if (!cleanedUp.compareAndSet(false, true)) return;
        stopRequested.set(true);
        cancelCountdown();
        removeCountdownOverlay();
        captureStarted = false;

        restoreDeviceMedia();
        finishOutput(false);

        try { if (virtualDisplay != null) virtualDisplay.release(); } catch (Exception ignored) {}
        virtualDisplay = null;
        try { if (audioRecord != null) audioRecord.release(); } catch (Exception ignored) {}
        audioRecord = null;
        try { if (videoInputSurface != null) videoInputSurface.release(); } catch (Exception ignored) {}
        videoInputSurface = null;
        try { if (videoCodec != null) { videoCodec.stop(); videoCodec.release(); } } catch (Exception ignored) {}
        videoCodec = null;
        try { if (audioCodec != null) { audioCodec.stop(); audioCodec.release(); } } catch (Exception ignored) {}
        audioCodec = null;
        try {
            if (projection != null && projectionCallback != null) {
                projection.unregisterCallback(projectionCallback);
            }
        } catch (Exception ignored) {}
        projectionCallback = null;
        try { if (projection != null) projection.stop(); } catch (Exception ignored) {}
        projection = null;

        CaptureState.set(this, CaptureState.IDLE, "待機中");
        try { stopForeground(STOP_FOREGROUND_REMOVE); } catch (Exception ignored) {}
        if (stopService) stopSelf();
    }

    private void joinQuietly(Thread t, long ms) {
        if (t == null) return;
        try { t.join(ms); } catch (InterruptedException ignored) {}
    }

    @Override public void onDestroy() {
        serviceAlive = false;
        if (!cleanedUp.get()) {
            stopRequested.set(true);
            cleanup(false);
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private static final class MuxerGate {
        private final MediaMuxer muxer;
        private int videoTrack = -1;
        private int audioTrack = -1;
        private boolean started;
        private boolean stopped;
        private long firstVideoPts = -1;
        private long firstAudioPts = -1;
        private Runnable onStarted;

        MuxerGate(MediaMuxer muxer) { this.muxer = muxer; }

        synchronized void setOnStarted(Runnable r) { onStarted = r; }

        synchronized void onVideoFormat(MediaFormat f) {
            if (videoTrack < 0) videoTrack = muxer.addTrack(f);
            maybeStart();
        }

        synchronized void onAudioFormat(MediaFormat f) {
            if (audioTrack < 0) audioTrack = muxer.addTrack(f);
            maybeStart();
        }

        private void maybeStart() {
            if (!started && videoTrack >= 0 && audioTrack >= 0) {
                muxer.start();
                started = true;
                if (onStarted != null) onStarted.run();
            }
        }

        synchronized void writeVideo(java.nio.ByteBuffer buffer, MediaCodec.BufferInfo info) {
            if (!started || stopped || videoTrack < 0) return;
            if (firstVideoPts < 0) firstVideoPts = info.presentationTimeUs;
            write(videoTrack, buffer, info,
                    Math.max(0, info.presentationTimeUs - firstVideoPts));
        }

        synchronized void writeAudio(java.nio.ByteBuffer buffer, MediaCodec.BufferInfo info) {
            if (!started || stopped || audioTrack < 0) return;
            if (firstAudioPts < 0) firstAudioPts = info.presentationTimeUs;
            write(audioTrack, buffer, info,
                    Math.max(0, info.presentationTimeUs - firstAudioPts));
        }

        private void write(int track, java.nio.ByteBuffer buffer,
                           MediaCodec.BufferInfo src, long pts) {
            MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
            bi.set(src.offset, src.size, pts, src.flags);
            buffer.position(src.offset);
            buffer.limit(src.offset + src.size);
            muxer.writeSampleData(track, buffer, bi);
        }

        synchronized void stop() {
            if (stopped) return;
            stopped = true;
            if (started) {
                try { muxer.stop(); } catch (Exception ignored) {}
            }
            try { muxer.release(); } catch (Exception ignored) {}
        }
    }
}
