package jp.groovy.audiocaptureprobe;

import android.app.*;
import android.content.*;
import android.media.*;
import android.media.projection.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class CaptureService extends Service {
    private static final String CH="capture";
    private volatile boolean running;
    private AudioRecord record;
    private MediaProjection projection;
    private Thread worker;

    @Override public void onCreate() {
        super.onCreate();
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CH,"Capture",NotificationManager.IMPORTANCE_LOW));
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId) {
        Notification n=new Notification.Builder(this,CH).setContentTitle("Audio Capture Probe")
                .setContentText("内部音声を10秒キャプチャ中").setSmallIcon(android.R.drawable.ic_btn_speak_now).build();
        startForeground(1,n,android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);

        int resultCode=intent.getIntExtra("resultCode",Activity.RESULT_CANCELED);
        Intent data=intent.getParcelableExtra("data",Intent.class);
        MediaProjectionManager mpm=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        projection=mpm.getMediaProjection(resultCode,data);
        captureTenSeconds();
        return START_NOT_STICKY;
    }

    private void captureTenSeconds() {
        worker=new Thread(() -> {
            final int rate=48000;
            final int channelMask=AudioFormat.CHANNEL_IN_STEREO;
            final int encoding=AudioFormat.ENCODING_PCM_16BIT;
            int min=AudioRecord.getMinBufferSize(rate,channelMask,encoding);
            int bufSize=Math.max(min, rate*2*2/5);
            AudioPlaybackCaptureConfiguration cfg=new AudioPlaybackCaptureConfiguration.Builder(projection)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build();
            AudioFormat fmt=new AudioFormat.Builder().setEncoding(encoding).setSampleRate(rate).setChannelMask(channelMask).build();
            record=new AudioRecord.Builder().setAudioFormat(fmt).setBufferSizeInBytes(bufSize)
                    .setAudioPlaybackCaptureConfig(cfg).build();
            ByteArrayOutputStream pcm=new ByteArrayOutputStream();
            byte[] buf=new byte[bufSize];
            long end=SystemClock.elapsedRealtime()+10000;
            long sumAbs=0; long samples=0;
            try {
                record.startRecording(); running=true;
                while(running && SystemClock.elapsedRealtime()<end) {
                    int n=record.read(buf,0,buf.length);
                    if(n>0) {
                        pcm.write(buf,0,n);
                        for(int i=0;i+1<n;i+=2){ short s=(short)((buf[i]&0xff)|(buf[i+1]<<8)); sumAbs+=Math.abs((int)s); samples++; }
                    }
                }
                Uri uri=saveWav(pcm.toByteArray(),rate,2,16);
                double avg=samples==0?0:(double)sumAbs/samples;
                notifyDone(uri,avg,pcm.size());
            } catch(Exception e) {
                notifyError(e.toString());
            } finally {
                try { if(record!=null){ record.stop(); record.release(); } } catch(Exception ignored){}
                if(projection!=null) projection.stop();
                stopForeground(STOP_FOREGROUND_REMOVE); stopSelf();
            }
        });
        worker.start();
    }

    private Uri saveWav(byte[] pcm,int rate,int channels,int bits) throws IOException {
        String ts=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());
        ContentValues v=new ContentValues();
        v.put(MediaStore.Audio.Media.DISPLAY_NAME,"capture_"+ts+".wav");
        v.put(MediaStore.Audio.Media.MIME_TYPE,"audio/wav");
        v.put(MediaStore.Audio.Media.RELATIVE_PATH,"Music/AudioCaptureProbe");
        Uri uri=getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,v);
        if(uri==null) throw new IOException("MediaStore insert failed");
        try(OutputStream os=getContentResolver().openOutputStream(uri)) {
            writeWavHeader(os,pcm.length,rate,channels,bits); os.write(pcm);
        }
        return uri;
    }

    private void writeWavHeader(OutputStream os,int dataLen,int rate,int channels,int bits) throws IOException {
        int byteRate=rate*channels*bits/8; int total=dataLen+36;
        ByteArrayOutputStream h=new ByteArrayOutputStream(); DataOutputStream d=new DataOutputStream(h);
        d.writeBytes("RIFF"); writeLE32(d,total); d.writeBytes("WAVEfmt "); writeLE32(d,16); writeLE16(d,1);
        writeLE16(d,channels); writeLE32(d,rate); writeLE32(d,byteRate); writeLE16(d,channels*bits/8); writeLE16(d,bits);
        d.writeBytes("data"); writeLE32(d,dataLen); os.write(h.toByteArray());
    }
    private void writeLE16(DataOutputStream d,int v)throws IOException{ d.writeByte(v&255); d.writeByte((v>>>8)&255); }
    private void writeLE32(DataOutputStream d,int v)throws IOException{ d.writeByte(v&255); d.writeByte((v>>>8)&255); d.writeByte((v>>>16)&255); d.writeByte((v>>>24)&255); }

    private void notifyDone(Uri uri,double avg,int bytes) {
        Notification n=new Notification.Builder(this,CH).setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("キャプチャ完了")
                .setContentText(String.format(Locale.US,"avg=%.1f / %d bytes",avg,bytes)).setAutoCancel(true).build();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(2,n);
    }
    private void notifyError(String s) {
        Notification n=new Notification.Builder(this,CH).setSmallIcon(android.R.drawable.stat_notify_error)
                .setContentTitle("キャプチャ失敗").setContentText(s).setAutoCancel(true).build();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(3,n);
    }

    @Override public void onDestroy(){ running=false; super.onDestroy(); }
    @Override public IBinder onBind(Intent intent){ return null; }
}
