package jp.groovy.audiocaptureprobe;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.TextView;

public class OverlayService extends Service {
    public static final String ACTION_SHOW = "jp.groovy.audiocaptureprobe.SHOW_FLOAT";
    private static final String CHANNEL = "capture_ready";
    private static final int NOTIFICATION_ID = 40;

    private WindowManager windowManager;
    private View floatView;
    private WindowManager.LayoutParams params;

    @Override public void onCreate() {
        super.onCreate();
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Capture ready", NotificationManager.IMPORTANCE_LOW));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (CaptureState.isActive(this) && CaptureService.isServiceAlive()) {
            removeFloat();
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return START_NOT_STICKY;
        }

        Notification notification = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.presence_video_online)
                .setContentTitle("Audio Capture Probe")
                .setContentText("フロートREC待機中")
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }

        if (Settings.canDrawOverlays(this)) showFloat();
        else stopSelf();
        return START_NOT_STICKY;
    }

    private void showFloat() {
        if (floatView != null) return;
        windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);

        TextView v = new TextView(this);
        v.setText("●\nREC");
        v.setTextColor(Color.WHITE);
        v.setTextSize(12f);
        v.setGravity(Gravity.CENTER);
        v.setPadding(0, 0, 0, 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(Color.rgb(68, 17, 0));
        bg.setStroke(dp(2), Color.rgb(136, 34, 17));
        v.setBackground(bg);
        v.setElevation(dp(8));

        params = new WindowManager.LayoutParams(
                dp(62), dp(62),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                android.graphics.PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = dp(12);
        params.y = dp(160);

        v.setOnTouchListener(new View.OnTouchListener() {
            int startX, startY;
            float downX, downY;
            long downAt;
            boolean moved;

            @Override public boolean onTouch(View view, android.view.MotionEvent e) {
                switch (e.getActionMasked()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        startX = params.x;
                        startY = params.y;
                        downX = e.getRawX();
                        downY = e.getRawY();
                        downAt = SystemClock.elapsedRealtime();
                        moved = false;
                        return true;
                    case android.view.MotionEvent.ACTION_MOVE:
                        int dx = (int)(e.getRawX() - downX);
                        int dy = (int)(e.getRawY() - downY);
                        if (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5)) moved = true;
                        params.x = startX + dx;
                        params.y = startY + dy;
                        try { windowManager.updateViewLayout(floatView, params); } catch (Exception ignored) {}
                        return true;
                    case android.view.MotionEvent.ACTION_UP:
                        long elapsed = SystemClock.elapsedRealtime() - downAt;
                        if (!moved && elapsed < 500) startProjectionPermission();
                        return true;
                }
                return false;
            }
        });

        floatView = v;
        windowManager.addView(floatView, params);
    }

    private void startProjectionPermission() {
        removeFloat();
        stopForeground(STOP_FOREGROUND_REMOVE);
        Intent i = new Intent(this, ProjectionActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        try {
            startActivity(i);
        } finally {
            stopSelf();
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void removeFloat() {
        if (floatView != null && windowManager != null) {
            try { windowManager.removeView(floatView); } catch (Exception ignored) {}
            floatView = null;
        }
    }

    @Override public void onDestroy() {
        removeFloat();
        super.onDestroy();
    }

    @Override public android.os.IBinder onBind(Intent intent) { return null; }
}
