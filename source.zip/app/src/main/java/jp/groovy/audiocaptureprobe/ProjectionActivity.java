package jp.groovy.audiocaptureprobe;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionConfig;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;

public class ProjectionActivity extends Activity {
    private static final int REQ_AUDIO = 20;
    private static final int REQ_CAPTURE = 21;
    private MediaProjectionManager projectionManager;
    private boolean launched;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        projectionManager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        begin();
    }

    private void begin() {
        if (launched) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        launched = true;
        Intent captureIntent;
        if (Build.VERSION.SDK_INT >= 34) {
            captureIntent = projectionManager.createScreenCaptureIntent(
                    MediaProjectionConfig.createConfigForDefaultDisplay());
        } else {
            captureIntent = projectionManager.createScreenCaptureIntent();
        }
        startActivityForResult(captureIntent, REQ_CAPTURE);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode, permissions, grants);
        if (requestCode == REQ_AUDIO && grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED) {
            begin();
        } else {
            restoreFloatAndFinish();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAPTURE) return;
        if (resultCode == RESULT_OK && data != null) {
            Intent i = new Intent(this, CaptureService.class);
            i.setAction(CaptureService.ACTION_START);
            i.putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode);
            i.putExtra(CaptureService.EXTRA_RESULT_DATA, data);
            startForegroundService(i);
            finishAndRemoveTask();
        } else {
            restoreFloatAndFinish();
        }
    }

    private void restoreFloatAndFinish() {
        try {
            Intent i = new Intent(this, OverlayService.class);
            i.setAction(OverlayService.ACTION_SHOW);
            startForegroundService(i);
        } catch (Exception ignored) {}
        finishAndRemoveTask();
    }
}
