package jp.groovy.audiocaptureprobe;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 10;
    private static final int REQ_OVERLAY = 12;
    private static final int REQ_NOTIFICATION = 13;

    private TextView status;
    private Button floatButton;
    private Button stopButton;
    private boolean waitingForOverlay;
    private boolean receiverRegistered;

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            refreshState();
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        if (CaptureState.isActive(this) && !CaptureService.isServiceAlive()) {
            CaptureState.set(this, CaptureState.IDLE, "待機中");
        }
        status = findViewById(R.id.status);
        floatButton = findViewById(R.id.floatButton);
        stopButton = findViewById(R.id.stopButton);

        floatButton.setOnClickListener(v -> prepareFloatingButton());
        stopButton.setOnClickListener(v -> requestStop());
        refreshState();
    }

    @Override protected void onStart() {
        super.onStart();
        IntentFilter f = new IntentFilter(CaptureState.ACTION_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(stateReceiver, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(stateReceiver, f);
        }
        receiverRegistered = true;
        refreshState();
    }

    @Override protected void onStop() {
        if (receiverRegistered) {
            try { unregisterReceiver(stateReceiver); } catch (Exception ignored) {}
            receiverRegistered = false;
        }
        super.onStop();
    }

    private void prepareFloatingButton() {
        if (CaptureState.isActive(this)) {
            refreshState();
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATION);
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            waitingForOverlay = true;
            status.setText("フロート表示の許可待ち…");
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(i, REQ_OVERLAY);
            return;
        }
        showFloatingButton();
    }

    private void showFloatingButton() {
        Intent i = new Intent(this, OverlayService.class);
        i.setAction(OverlayService.ACTION_SHOW);
        startForegroundService(i);
        status.setText("フロートREC表示中。対象アプリへ移動してください");
    }

    private void requestStop() {
        stopButton.setEnabled(false);
        status.setText("停止処理中…");
        Intent i = new Intent(this, CaptureService.class);
        i.setAction(CaptureService.ACTION_STOP);
        try {
            startService(i);
        } catch (Exception e) {
            try { stopService(new Intent(this, CaptureService.class)); } catch (Exception ignored) {}
            CaptureState.set(this, CaptureState.IDLE, "停止済み");
        }
    }

    private void refreshState() {
        String s = CaptureState.getState(this);
        String detail = CaptureState.getDetail(this);
        boolean active = CaptureState.COUNTDOWN.equals(s) ||
                CaptureState.RECORDING.equals(s) || CaptureState.STOPPING.equals(s);

        floatButton.setEnabled(!active);
        stopButton.setEnabled(active && !CaptureState.STOPPING.equals(s));
        stopButton.setVisibility(View.VISIBLE);

        if (CaptureState.COUNTDOWN.equals(s)) {
            status.setText(detail.isEmpty() ? "録画開始カウントダウン中" : detail);
        } else if (CaptureState.RECORDING.equals(s)) {
            status.setText(detail.isEmpty() ? "録画中" : detail);
        } else if (CaptureState.STOPPING.equals(s)) {
            status.setText("停止処理中…");
        } else {
            status.setText(detail.isEmpty() ? "待機中" : detail);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (waitingForOverlay && Settings.canDrawOverlays(this)) {
            waitingForOverlay = false;
            showFloatingButton();
        }
        refreshState();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode, permissions, grants);
        if (requestCode == REQ_AUDIO) {
            if (grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED) {
                prepareFloatingButton();
            } else {
                status.setText("内部音声キャプチャにはRECORD_AUDIO権限が必要です");
            }
        } else if (requestCode == REQ_NOTIFICATION) {
            if (grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED) {
                prepareFloatingButton();
            } else {
                status.setText("録画停止ボタンを通知へ出すため通知権限が必要です");
            }
        }
    }
}
