package jp.groovy.audiocaptureprobe;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 10;
    private static final int REQ_CAPTURE = 11;
    private MediaProjectionManager mpm;
    private TextView status, path;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        status = findViewById(R.id.status);
        path = findViewById(R.id.path);
        mpm = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        Button start = findViewById(R.id.startButton);
        start.setOnClickListener(v -> begin());
    }

    private void begin() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        status.setText("画面共有の許可待ち…");
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode, permissions, grants);
        if (requestCode == REQ_AUDIO && grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED) begin();
        else status.setText("RECORD_AUDIO 権限が必要です");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CAPTURE) {
            if (resultCode != RESULT_OK || data == null) { status.setText("キャンセルしました"); return; }
            Intent i = new Intent(this, CaptureService.class);
            i.putExtra("resultCode", resultCode);
            i.putExtra("data", data);
            startForegroundService(i);
            status.setText("キャプチャ中：対象アプリへ戻って再生してください");
            path.setText("10秒後に Music/AudioCaptureProbe へ保存");
        }
    }
}
