package jp.groovy.audiocaptureprobe;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 10;
    private static final int REQ_OVERLAY = 12;
    private static final int REQ_NOTIFICATION = 13;
    private TextView status;
    private boolean waitingForOverlay;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        status = findViewById(R.id.status);
        Button floatButton = findViewById(R.id.floatButton);
        floatButton.setOnClickListener(v -> prepareFloatingButton());

    }

    private void prepareFloatingButton() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATION);
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            waitingForOverlay = true;
            status.setText("フロート表示の許可待ち…");
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(i, REQ_OVERLAY);
            return;
        }
        showFloatingButton();
    }

    private void showFloatingButton() {
        Intent i = new Intent(this, OverlayService.class);
        i.setAction(OverlayService.ACTION_SHOW);
        startForegroundService(i);
        status.setText("フロートREC表示中。対象アプリへ移動してください");
    }

    @Override protected void onResume() {
        super.onResume();
        if (waitingForOverlay && Settings.canDrawOverlays(this)) {
            waitingForOverlay = false;
            showFloatingButton();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode, permissions, grants);
        if (requestCode == REQ_AUDIO) {
            if (grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED) {
                prepareFloatingButton();
            } else {
                status.setText("内部音声キャプチャにはRECORD_AUDIO権限が必要です");
            }
        } else if (requestCode == REQ_NOTIFICATION) {
            if (grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED) {
                prepareFloatingButton();
            } else {
                status.setText("録画停止ボタンを通知へ出すため通知権限が必要です");
            }
        }
    }
}
